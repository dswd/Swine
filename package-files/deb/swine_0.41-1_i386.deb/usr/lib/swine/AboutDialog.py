# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'AboutDialog.ui'
#
# Created: Mo Jun 9 23:16:19 2008
#      by: The PyQt User Interface Compiler (pyuic) 3.17.4
#
# WARNING! All changes made in this file will be lost!


from qt import *

image0_data = \
    "\x89\x50\x4e\x47\x0d\x0a\x1a\x0a\x00\x00\x00\x0d" \
    "\x49\x48\x44\x52\x00\x00\x00\x20\x00\x00\x00\x20" \
    "\x08\x06\x00\x00\x00\x73\x7a\x7a\xf4\x00\x00\x06" \
    "\x55\x49\x44\x41\x54\x58\x85\xed\x97\x4d\x6c\x5d" \
    "\x47\x15\xc7\x7f\x33\x73\xdf\x87\xed\xe7\xaf\xc4" \
    "\x4e\x1d\x2b\x71\x42\x93\x34\x69\x08\x6d\x13\x13" \
    "\x27\xa1\x84\x0a\x01\x95\x5a\x84\xd8\xb0\xa9\x10" \
    "\x12\x52\x11\x42\x02\x04\x2b\x24\x16\x48\x6c\x58" \
    "\xf0\xb5\x67\x91\x15\x1b\x60\x01\x08\x8a\x02\x6d" \
    "\x44\x2b\x0a\x51\xb1\x12\x52\xf5\x2b\x49\x4d\x43" \
    "\x1a\x9b\x24\x4a\x9c\xc4\xb1\xfd\xbe\xee\xbd\x33" \
    "\xe7\xb0\x98\xfb\x9e\xbf\x02\x64\x17\x16\x8c\xde" \
    "\xd1\xbd\x77\xee\xcc\x9c\xff\xfd\x9f\xff\x39\x33" \
    "\xcf\xa8\x2a\x0f\xb2\xd9\x07\xea\xfd\x7f\x01\x40" \
    "\x02\x60\x07\xf6\x1f\x57\x86\x8f\x41\x30\xb1\xdb" \
    "\xac\x8c\x30\xeb\x66\x98\x7b\x74\xfe\x87\x31\xc6" \
    "\x50\x5e\xe9\x36\x80\x62\x8c\x09\xb4\x66\x4f\xf9" \
    "\xc6\xec\x99\xc4\x0d\x1c\x78\x66\xf7\xd4\x57\x7e" \
    "\xfd\xe4\xa1\x5d\x15\x54\x09\xa2\x88\x2a\x22\x85" \
    "\xa9\x22\x02\x22\x82\x2a\x2b\xef\x56\xf5\x8b\xd2" \
    "\xed\x53\xd1\xe2\x59\xe2\xfb\x75\xe3\x55\x85\xe5" \
    "\x46\x83\x9b\xd7\x66\xbe\xee\x2a\x43\x1f\x4f\xc4" \
    "\x0d\x3f\xf5\xc9\x63\xfb\x2a\x5f\xfc\xcc\x7e\x96" \
    "\xea\x19\x79\x10\x7c\x10\x42\x10\x72\x2f\x78\xaf" \
    "\xf8\xa0\xe4\xde\x13\x24\xde\x7b\x1f\xc8\x83\x12" \
    "\xbc\xe2\x43\xc0\x7b\x25\xf7\x8a\x17\x4f\x08\x9d" \
    "\xf1\xb1\x3f\x3e\x17\x6b\x85\xf8\x81\xb7\x17\x1c" \
    "\xcb\x8b\x83\x63\x8d\x64\xe8\x58\x82\x8a\x37\x06" \
    "\x96\x1b\x29\x4b\xf5\x94\x5c\xe2\x84\xe0\x05\x5f" \
    "\x4c\xca\x0b\xa7\x41\xb4\x00\xe4\xd7\x02\x08\x8a" \
    "\xcf\x95\x5c\x42\x17\x80\x0f\x9e\x3c\x5f\x01\x10" \
    "\x41\x44\x00\xf5\x66\x46\x08\x1e\x55\x31\x09\xaa" \
    "\x0c\x0e\x54\x18\xdd\xdc\x83\xb1\x82\x48\x11\x06" \
    "\x51\x44\x84\x10\xe8\x86\x45\xad\x43\x5d\x82\x62" \
    "\x09\x41\xf0\x59\x8e\x4f\x53\x42\x01\x4e\x54\x63" \
    "\x98\x64\x75\x28\x59\x1b\x02\x03\xad\xf6\x30\xcb" \
    "\xcb\xd7\xb9\x13\x82\x26\x88\x32\x3e\xd6\xcf\xe8" \
    "\x26\xcb\xe8\xe8\x30\xce\xd9\x75\x9a\x8a\xc2\xa1" \
    "\x54\xa6\x3d\x3f\xcf\x9d\x77\xde\xa6\x3e\x7f\x1d" \
    "\x57\xae\x30\xb0\x6b\x1f\x43\x7b\xf6\xd2\xd3\x5b" \
    "\x41\xb2\x14\x63\x0c\x98\x28\x35\xb3\x46\xac\xa6" \
    "\xf3\x23\x49\x1c\xe5\x72\xc2\x85\x77\x2f\x72\xfe" \
    "\xe5\x10\xb3\x20\x16\x23\xc3\xd8\xd8\xe6\xb8\xc8" \
    "\x3d\xda\xc2\x2f\x7f\x41\xfd\xfb\xdf\xa6\xa6\xff" \
    "\x64\x4b\x5f\x8e\xa9\x42\x23\xa9\x71\x7b\xe2\x63" \
    "\x6c\xfd\xd2\x77\x19\x39\x74\x78\xcd\xf8\x0e\x13" \
    "\xa8\x29\x84\x1a\xd9\x75\xd6\x12\x42\x40\x42\x00" \
    "\x34\x02\xe8\xb4\x10\x84\x24\x71\x1b\x9c\x4b\x50" \
    "\xee\x9e\xf8\x11\x43\x8b\x97\x29\x6f\x81\xa4\x02" \
    "\xa5\x5e\xd8\x52\xab\xd3\xf8\xfb\x49\x2e\xfc\x66" \
    "\x37\x6f\x0c\xb7\x38\x36\x7e\x84\xde\x4a\xa5\xcb" \
    "\x9b\x33\x86\x34\x17\xd2\xd0\xc6\x91\xd0\xa9\xba" \
    "\x2a\x82\x4a\xbc\x4f\x36\x78\xbb\x47\xcb\x66\xde" \
    "\x45\x2f\xbf\x85\xa9\x81\xda\xc2\x0c\x88\x01\xad" \
    "\x56\x98\xdd\x3e\xc2\x0f\xce\x3e\xcb\xae\xea\xa3" \
    "\x1c\x1d\x7b\x86\x1d\x83\x7b\xc0\xe5\x5c\x6b\x5d" \
    "\xe1\xe2\xe2\x39\x3e\x37\xf1\x35\x3e\x32\xf2\x34" \
    "\xcd\x3c\xc5\xda\xc8\xb8\xa8\xdc\x3f\x80\xe6\x9f" \
    "\x4e\x61\x1b\x29\x0c\x80\xb1\xd1\x30\xe0\x04\xea" \
    "\xe5\x87\x79\x6f\x34\xa5\x5a\x6e\x70\x95\xb3\x9c" \
    "\x78\xff\x2c\x16\x48\x05\xe6\x9b\xb0\x73\x08\xbe" \
    "\xb9\xf7\x87\x78\x89\x8e\xb5\x08\x85\xaa\x6c\x0c" \
    "\xc1\x3d\x9b\x42\xf6\xe7\x97\x70\x49\xa4\xd5\x00" \
    "\xd6\x80\x75\x90\x37\xe1\xee\xf8\xe3\x5c\xb4\xe7" \
    "\x69\xe7\x60\x24\x8a\xaf\x99\x41\x2b\x03\x0d\x70" \
    "\x60\xf0\x08\x9b\xcb\x3b\xc8\x43\x5e\x00\x88\x8b" \
    "\xaa\x04\xe0\x3e\xf6\x02\x3f\x37\x47\xfb\xf4\x49" \
    "\x28\x83\x54\xa0\xad\xd0\x5c\x02\x93\x43\x48\xe1" \
    "\xc6\xc4\x1e\x66\xb2\x37\xc9\x03\x2c\xb7\xa1\xde" \
    "\x86\x46\x16\xad\xe5\xe1\xb1\x4d\x47\xe8\x73\x3d" \
    "\x88\x04\x54\x41\x05\x44\x88\x37\xf7\xc3\x80\x9d" \
    "\xbb\xc4\xf8\xe7\x9f\x63\xf9\x91\x27\xb8\x9d\x6c" \
    "\xc1\xf5\x96\x29\x2f\x5f\xe7\xca\x6b\xbf\x25\x3f" \
    "\x77\x86\x4b\x63\x09\x37\xdb\xb3\x18\x0b\xed\x0c" \
    "\x52\x1f\xad\x99\xc1\x48\x3f\xec\xed\x9f\x5a\x55" \
    "\xc2\x05\x75\x36\x86\xe1\x7e\x01\xdc\xda\x7d\x8c" \
    "\x17\x26\x8f\xf2\xd2\x39\xcf\x95\xd9\xbb\x7c\x60" \
    "\xab\xf0\x89\xa9\x5e\x9e\xfa\xc6\x17\xa8\xbe\xfe" \
    "\x2a\xe7\xed\x29\x6e\x2c\xe5\xf4\x97\x21\xcd\x57" \
    "\x00\xf8\x0c\x06\x2a\x8e\x3d\xb5\x03\xa4\x21\x74" \
    "\xe9\x57\xe9\x5c\x05\xf4\xbf\x00\x90\xa0\x3c\xf7" \
    "\x9d\x26\x2f\xbf\x1a\x60\xc0\xd2\xb7\x65\x90\x99" \
    "\x96\xf0\xca\x5c\xc6\xe6\x9f\xcd\x73\xe2\x5b\x4f" \
    "\x73\xbc\x94\xf1\xfb\x33\xa7\x99\x6b\xbe\x4d\x23" \
    "\x53\x10\xc0\xc1\xd0\xa6\x1a\x53\x0f\x4d\x32\x5a" \
    "\xde\x89\x0f\x79\x74\xaa\x8a\x46\x05\x74\x53\xb2" \
    "\x0b\xc0\xda\x8d\x05\xe8\xe2\x65\xcf\x5f\xde\x14" \
    "\xa8\x59\x7a\xfa\x2d\x3d\x65\xa5\xb7\x96\xd0\x37" \
    "\xd2\xc3\xad\x4b\xca\xad\x99\x57\xf8\xec\xfe\xdf" \
    "\x31\x39\xf9\x65\x5e\x6b\x04\xde\xcf\xe6\xc1\xb5" \
    "\x18\x29\x2b\x7b\x69\xf2\xc8\xb6\xe7\x31\xb6\x8f" \
    "\xe0\xdb\x2b\x0c\x14\x3b\xa6\x6a\x58\x0b\xc0\xb9" \
    "\x8d\x7a\xfc\xe3\xb4\x27\x5b\x06\x6a\x51\xdd\xc6" \
    "\x18\x8c\x85\x2c\x83\xf1\x72\xca\xc1\xed\x17\xb0" \
    "\xbb\x4e\x32\x61\x7e\xc5\xc4\x9d\x4d\x10\xb6\x81" \
    "\xa4\xc0\x4d\x58\x6a\x50\x37\x5f\x25\x95\x4e\x55" \
    "\x2c\xf6\x04\x29\x16\x5f\xa3\x01\x03\xce\x39\xd6" \
    "\x57\xe1\x17\xa7\x3d\x18\xb0\x36\xa6\x9d\x75\x60" \
    "\x13\x68\x2c\xa6\x1c\x1f\x6f\x33\x32\x3c\x0d\x7d" \
    "\x0b\x71\x70\xe9\x2a\x64\x57\x21\x05\x3c\x84\xe6" \
    "\x41\xb2\xd2\x0e\x34\xe4\x45\xde\x77\x68\x97\x55" \
    "\x1e\xb4\x93\x86\x06\x67\x8b\xea\x52\xb4\xab\x37" \
    "\x84\xd3\x6f\x04\xb0\x06\x51\x8b\x37\x16\x75\x16" \
    "\x97\x38\x42\x23\xe3\xf0\xc4\x1d\x2a\xd5\xe9\xb8" \
    "\x5e\x1d\x58\x2e\xac\x0e\xdc\x85\xdc\x1e\x25\x94" \
    "\x6a\x88\xf8\xb5\xf4\x77\xce\xc0\xab\x35\x60\x00" \
    "\xe7\xd6\x7e\xfe\xa9\x69\xa1\x25\xca\xf6\x1d\x81" \
    "\xc1\x6a\x13\xef\x73\x16\x17\x0d\x0b\x66\x88\x72" \
    "\xab\xcd\xe1\x87\xdf\x83\xd2\x35\x68\x02\x2d\x20" \
    "\x2b\xac\x60\x20\x4f\xa6\x10\x6b\x20\x74\x9c\x4b" \
    "\x77\x83\x72\x76\x7d\x08\x00\xbb\x2e\x04\xfb\x76" \
    "\x1a\x4e\xfe\xb8\x8f\x0f\xed\x86\x6a\xa2\x84\x10" \
    "\xb8\xf4\x8f\x3a\x3f\x3f\x79\x8d\xcb\x73\xb0\x6d" \
    "\xf0\x34\x26\xd1\x08\xa0\xbd\xca\x79\x0e\xe4\x15" \
    "\xf2\xf1\x0f\x43\xc8\xba\x5f\x2e\xb2\x8e\x01\xd6" \
    "\x65\x81\x73\x2b\xbb\xa0\x2a\x1c\x7d\xcc\x02\x96" \
    "\xce\x39\x51\x35\x61\xf2\x50\x95\xc9\x27\x36\x71" \
    "\x77\x29\x90\x9e\x1f\xa4\x39\xeb\xa8\x0e\x06\xac" \
    "\x16\x8e\x53\xc0\x41\xae\x8f\x93\x27\xdb\x91\x90" \
    "\x17\x8a\xd7\xae\x0e\x44\x14\x75\x1d\x00\x91\x01" \
    "\xe3\x9c\xa5\x54\x72\x18\x1b\x25\xd1\x39\x4c\x44" \
    "\xf4\x2b\xac\xe4\x5e\x51\x35\xd4\xfa\x4b\x54\x0e" \
    "\x7e\x8f\xec\xda\xa7\x91\xe5\x17\x29\xd9\x4b\x24" \
    "\x89\x87\xea\x08\x62\x3f\x48\x7b\xe0\x53\x94\x7b" \
    "\x7b\x50\xf1\xa8\x9a\x78\x2e\x20\xd2\x5f\x2a\x39" \
    "\xac\x55\x62\xd6\xab\x49\x30\x96\x5b\x0b\x2d\x8c" \
    "\x8d\xc7\x2c\x54\xd7\x89\x66\x6d\x0c\x57\xd4\x6c" \
    "\xb0\x5b\x9f\x24\x8c\x7d\x14\x9f\x66\xa8\x06\xc4" \
    "\x94\x51\xe7\x30\xd2\x02\xdf\xea\x02\xef\x94\x18" \
    "\xeb\x0c\x86\xc0\xc2\x9d\x3a\x4b\xf5\x16\x18\x23" \
    "\x89\x0d\xd7\x5f\xf8\xc9\x4f\xff\xf0\xfc\x5b\x17" \
    "\x2e\x3f\xe4\x4c\x3c\xbb\x6d\x04\x11\x29\x5b\xdd" \
    "\x87\x12\x9d\x4a\x00\xd5\xb8\xd9\x88\x07\xf5\xc5" \
    "\xfc\x50\x08\x2d\xac\xdc\xab\x60\x0d\x2c\xd5\x1b" \
    "\xfc\xed\xf5\x33\x17\xa0\xfd\x57\xa3\xaa\x98\xd2" \
    "\xf0\xa3\x30\x38\x85\x4a\x37\x2d\x57\x5f\xfe\x7d" \
    "\xeb\xc4\x68\x95\xad\x7e\x56\xd9\xf8\x3e\x9a\xc7" \
    "\x34\xa7\x55\xf2\x19\xf3\xff\x3f\xa7\x0f\x1a\xc0" \
    "\xbf\x00\xfe\x76\x7b\xae\xea\x1d\xf2\x9a\x00\x00" \
    "\x00\x00\x49\x45\x4e\x44\xae\x42\x60\x82"

class AboutDialog(QDialog):
    def __init__(self,parent = None,name = None,modal = 0,fl = 0):
        QDialog.__init__(self,parent,name,modal,fl)

        self.image0 = QPixmap()
        self.image0.loadFromData(image0_data,"PNG")
        if not name:
            self.setName("AboutDialog")

        self.setSizeGripEnabled(1)

        AboutDialogLayout = QVBoxLayout(self,11,6,"AboutDialogLayout")

        layout4 = QHBoxLayout(None,0,3,"layout4")

        self.pixmapLabel1 = QLabel(self,"pixmapLabel1")
        self.pixmapLabel1.setPixmap(self.image0)
        self.pixmapLabel1.setScaledContents(1)
        layout4.addWidget(self.pixmapLabel1)

        self.versionLabel = QLabel(self,"versionLabel")
        versionLabel_font = QFont(self.versionLabel.font())
        versionLabel_font.setPointSize(13)
        versionLabel_font.setBold(1)
        self.versionLabel.setFont(versionLabel_font)
        layout4.addWidget(self.versionLabel)
        spacer4 = QSpacerItem(40,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout4.addItem(spacer4)
        AboutDialogLayout.addLayout(layout4)

        self.tabWidget = QTabWidget(self,"tabWidget")

        self.aboutPage = QWidget(self.tabWidget,"aboutPage")
        aboutPageLayout = QHBoxLayout(self.aboutPage,3,3,"aboutPageLayout")

        self.textEdit1 = QTextEdit(self.aboutPage,"textEdit1")
        self.textEdit1.setEnabled(1)
        self.textEdit1.setBackgroundOrigin(QTextEdit.WidgetOrigin)
        textEdit1_font = QFont(self.textEdit1.font())
        textEdit1_font.setPointSize(13)
        self.textEdit1.setFont(textEdit1_font)
        self.textEdit1.setWordWrap(QTextEdit.WidgetWidth)
        self.textEdit1.setReadOnly(1)
        aboutPageLayout.addWidget(self.textEdit1)
        self.tabWidget.insertTab(self.aboutPage,QString.fromLatin1(""))

        self.license = QWidget(self.tabWidget,"license")
        licenseLayout = QHBoxLayout(self.license,3,3,"licenseLayout")

        self.textEdit2 = QTextEdit(self.license,"textEdit2")
        self.textEdit2.setWordWrap(QTextEdit.WidgetWidth)
        licenseLayout.addWidget(self.textEdit2)
        self.tabWidget.insertTab(self.license,QString.fromLatin1(""))

        self.TabPage = QWidget(self.tabWidget,"TabPage")
        TabPageLayout = QHBoxLayout(self.TabPage,3,3,"TabPageLayout")

        self.textEdit3 = QTextEdit(self.TabPage,"textEdit3")
        self.textEdit3.setWordWrap(QTextEdit.WidgetWidth)
        self.textEdit3.setReadOnly(1)
        TabPageLayout.addWidget(self.textEdit3)
        self.tabWidget.insertTab(self.TabPage,QString.fromLatin1(""))
        AboutDialogLayout.addWidget(self.tabWidget)

        layout2 = QHBoxLayout(None,0,3,"layout2")
        Horizontal_Spacing2 = QSpacerItem(240,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout2.addItem(Horizontal_Spacing2)

        self.buttonClose = QPushButton(self,"buttonClose")
        self.buttonClose.setAutoDefault(1)
        self.buttonClose.setDefault(1)
        layout2.addWidget(self.buttonClose)
        spacer3 = QSpacerItem(240,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout2.addItem(spacer3)
        AboutDialogLayout.addLayout(layout2)

        self.languageChange()

        self.resize(QSize(531,303).expandedTo(self.minimumSizeHint()))
        self.clearWState(Qt.WState_Polished)

        self.connect(self.buttonClose,SIGNAL("clicked()"),self.accept)


    def languageChange(self):
        self.setCaption(self.__tr("About Swine"))
        self.versionLabel.setText(self.__tr("Swine Version VERSION"))
        self.textEdit1.setText(self.__tr("Swine is a graphical frontend for wine that can manage several slots.\n"
"\n"
"Autors:		Dennis Schwerdel\n"
"		Thomas Schmidt\n"
"		Klaus Denker\n"
"\n"
"Homepage: 	http://swine.sourceforge.net"))
        self.tabWidget.changeTab(self.aboutPage,self.__tr("&About"))
        self.textEdit2.setText(self.__tr("GNU GENERAL PUBLIC LICENSE\n"
"\n"
"Version 2, June 1991\n"
"\n"
"Copyright (C) 1989, 1991 Free Software Foundation, Inc.  \n"
"51 Franklin St, Fifth Floor, Boston, MA  02110-1301, USA\n"
"\n"
"Everyone is permitted to copy and distribute verbatim copies\n"
"of this license document, but changing it is not allowed.\n"
"\n"
"Preamble\n"
"\n"
"The licenses for most software are designed to take away your freedom to share and change it. By contrast, the GNU General Public License is intended to guarantee your freedom to share and change free software--to make sure the software is free for all its users. This General Public License applies to most of the Free Software Foundation's software and to any other program whose authors commit to using it. (Some other Free Software Foundation software is covered by the GNU Library General Public License instead.) You can apply it to your programs, too.\n"
"\n"
"When we speak of free software, we are referring to freedom, not price. Our General Public Licenses are designed to make sure that you have the freedom to distribute copies of free software (and charge for this service if you wish), that you receive source code or can get it if you want it, that you can change the software or use pieces of it in new free programs; and that you know you can do these things.\n"
"\n"
"To protect your rights, we need to make restrictions that forbid anyone to deny you these rights or to ask you to surrender the rights. These restrictions translate to certain responsibilities for you if you distribute copies of the software, or if you modify it.\n"
"\n"
"For example, if you distribute copies of such a program, whether gratis or for a fee, you must give the recipients all the rights that you have. You must make sure that they, too, receive or can get the source code. And you must show them these terms so they know their rights.\n"
"\n"
"We protect your rights with two steps: (1) copyright the software, and (2) offer you this license which gives you legal permission to copy, distribute and/or modify the software.\n"
"\n"
"Also, for each author's protection and ours, we want to make certain that everyone understands that there is no warranty for this free software. If the software is modified by someone else and passed on, we want its recipients to know that what they have is not the original, so that any problems introduced by others will not reflect on the original authors' reputations.\n"
"\n"
"Finally, any free program is threatened constantly by software patents. We wish to avoid the danger that redistributors of a free program will individually obtain patent licenses, in effect making the program proprietary. To prevent this, we have made it clear that any patent must be licensed for everyone's free use or not licensed at all.\n"
"\n"
"The precise terms and conditions for copying, distribution and modification follow.\n"
"TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION\n"
"\n"
"0. This License applies to any program or other work which contains a notice placed by the copyright holder saying it may be distributed under the terms of this General Public License. The \"Program\", below, refers to any such program or work, and a \"work based on the Program\" means either the Program or any derivative work under copyright law: that is to say, a work containing the Program or a portion of it, either verbatim or with modifications and/or translated into another language. (Hereinafter, translation is included without limitation in the term \"modification\".) Each licensee is addressed as \"you\".\n"
"\n"
"Activities other than copying, distribution and modification are not covered by this License; they are outside its scope. The act of running the Program is not restricted, and the output from the Program is covered only if its contents constitute a work based on the Program (independent of having been made by running the Program). Whether that is true depends on what the Program does.\n"
"\n"
"1. You may copy and distribute verbatim copies of the Program's source code as you receive it, in any medium, provided that you conspicuously and appropriately publish on each copy an appropriate copyright notice and disclaimer of warranty; keep intact all the notices that refer to this License and to the absence of any warranty; and give any other recipients of the Program a copy of this License along with the Program.\n"
"\n"
"You may charge a fee for the physical act of transferring a copy, and you may at your option offer warranty protection in exchange for a fee.\n"
"\n"
"2. You may modify your copy or copies of the Program or any portion of it, thus forming a work based on the Program, and copy and distribute such modifications or work under the terms of Section 1 above, provided that you also meet all of these conditions:\n"
"\n"
"    a) You must cause the modified files to carry prominent notices stating that you changed the files and the date of any change. \n"
"\n"
"    b) You must cause any work that you distribute or publish, that in whole or in part contains or is derived from the Program or any part thereof, to be licensed as a whole at no charge to all third parties under the terms of this License. \n"
"\n"
"    c) If the modified program normally reads commands interactively when run, you must cause it, when started running for such interactive use in the most ordinary way, to print or display an announcement including an appropriate copyright notice and a notice that there is no warranty (or else, saying that you provide a warranty) and that users may redistribute the program under these conditions, and telling the user how to view a copy of this License. (Exception: if the Program itself is interactive but does not normally print such an announcement, your work based on the Program is not required to print an announcement.) \n"
"\n"
"These requirements apply to the modified work as a whole. If identifiable sections of that work are not derived from the Program, and can be reasonably considered independent and separate works in themselves, then this License, and its terms, do not apply to those sections when you distribute them as separate works. But when you distribute the same sections as part of a whole which is a work based on the Program, the distribution of the whole must be on the terms of this License, whose permissions for other licensees extend to the entire whole, and thus to each and every part regardless of who wrote it.\n"
"\n"
"Thus, it is not the intent of this section to claim rights or contest your rights to work written entirely by you; rather, the intent is to exercise the right to control the distribution of derivative or collective works based on the Program.\n"
"\n"
"In addition, mere aggregation of another work not based on the Program with the Program (or with a work based on the Program) on a volume of a storage or distribution medium does not bring the other work under the scope of this License.\n"
"\n"
"3. You may copy and distribute the Program (or a work based on it, under Section 2) in object code or executable form under the terms of Sections 1 and 2 above provided that you also do one of the following:\n"
"\n"
"    a) Accompany it with the complete corresponding machine-readable source code, which must be distributed under the terms of Sections 1 and 2 above on a medium customarily used for software interchange; or, \n"
"\n"
"    b) Accompany it with a written offer, valid for at least three years, to give any third party, for a charge no more than your cost of physically performing source distribution, a complete machine-readable copy of the corresponding source code, to be distributed under the terms of Sections 1 and 2 above on a medium customarily used for software interchange; or, \n"
"\n"
"    c) Accompany it with the information you received as to the offer to distribute corresponding source code. (This alternative is allowed only for noncommercial distribution and only if you received the program in object code or executable form with such an offer, in accord with Subsection b above.) \n"
"\n"
"The source code for a work means the preferred form of the work for making modifications to it. For an executable work, complete source code means all the source code for all modules it contains, plus any associated interface definition files, plus the scripts used to control compilation and installation of the executable. However, as a special exception, the source code distributed need not include anything that is normally distributed (in either source or binary form) with the major components (compiler, kernel, and so on) of the operating system on which the executable runs, unless that component itself accompanies the executable.\n"
"\n"
"If distribution of executable or object code is made by offering access to copy from a designated place, then offering equivalent access to copy the source code from the same place counts as distribution of the source code, even though third parties are not compelled to copy the source along with the object code.\n"
"\n"
"4. You may not copy, modify, sublicense, or distribute the Program except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense or distribute the Program is void, and will automatically terminate your rights under this License. However, parties who have received copies, or rights, from you under this License will not have their licenses terminated so long as such parties remain in full compliance.\n"
"\n"
"5. You are not required to accept this License, since you have not signed it. However, nothing else grants you permission to modify or distribute the Program or its derivative works. These actions are prohibited by law if you do not accept this License. Therefore, by modifying or distributing the Program (or any work based on the Program), you indicate your acceptance of this License to do so, and all its terms and conditions for copying, distributing or modifying the Program or works based on it.\n"
"\n"
"6. Each time you redistribute the Program (or any work based on the Program), the recipient automatically receives a license from the original licensor to copy, distribute or modify the Program subject to these terms and conditions. You may not impose any further restrictions on the recipients' exercise of the rights granted herein. You are not responsible for enforcing compliance by third parties to this License.\n"
"\n"
"7. If, as a consequence of a court judgment or allegation of patent infringement or for any other reason (not limited to patent issues), conditions are imposed on you (whether by court order, agreement or otherwise) that contradict the conditions of this License, they do not excuse you from the conditions of this License. If you cannot distribute so as to satisfy simultaneously your obligations under this License and any other pertinent obligations, then as a consequence you may not distribute the Program at all. For example, if a patent license would not permit royalty-free redistribution of the Program by all those who receive copies directly or indirectly through you, then the only way you could satisfy both it and this License would be to refrain entirely from distribution of the Program.\n"
"\n"
"If any portion of this section is held invalid or unenforceable under any particular circumstance, the balance of the section is intended to apply and the section as a whole is intended to apply in other circumstances.\n"
"\n"
"It is not the purpose of this section to induce you to infringe any patents or other property right claims or to contest validity of any such claims; this section has the sole purpose of protecting the integrity of the free software distribution system, which is implemented by public license practices. Many people have made generous contributions to the wide range of software distributed through that system in reliance on consistent application of that system; it is up to the author/donor to decide if he or she is willing to distribute software through any other system and a licensee cannot impose that choice.\n"
"\n"
"This section is intended to make thoroughly clear what is believed to be a consequence of the rest of this License.\n"
"\n"
"8. If the distribution and/or use of the Program is restricted in certain countries either by patents or by copyrighted interfaces, the original copyright holder who places the Program under this License may add an explicit geographical distribution limitation excluding those countries, so that distribution is permitted only in or among countries not thus excluded. In such case, this License incorporates the limitation as if written in the body of this License.\n"
"\n"
"9. The Free Software Foundation may publish revised and/or new versions of the General Public License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns.\n"
"\n"
"Each version is given a distinguishing version number. If the Program specifies a version number of this License which applies to it and \"any later version\", you have the option of following the terms and conditions either of that version or of any later version published by the Free Software Foundation. If the Program does not specify a version number of this License, you may choose any version ever published by the Free Software Foundation.\n"
"\n"
"10. If you wish to incorporate parts of the Program into other free programs whose distribution conditions are different, write to the author to ask for permission. For software which is copyrighted by the Free Software Foundation, write to the Free Software Foundation; we sometimes make exceptions for this. Our decision will be guided by the two goals of preserving the free status of all derivatives of our free software and of promoting the sharing and reuse of software generally.\n"
"\n"
"NO WARRANTY\n"
"\n"
"11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM \"AS IS\" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU. SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION.\n"
"\n"
"12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.\n"
"END OF TERMS AND CONDITIONS\n"
"How to Apply These Terms to Your New Programs\n"
"\n"
"If you develop a new program, and you want it to be of the greatest possible use to the public, the best way to achieve this is to make it free software which everyone can redistribute and change under these terms.\n"
"\n"
"To do so, attach the following notices to the program. It is safest to attach them to the start of each source file to most effectively convey the exclusion of warranty; and each file should have at least the \"copyright\" line and a pointer to where the full notice is found.\n"
"\n"
"one line to give the program's name and an idea of what it does.\n"
"Copyright (C) yyyy  name of author\n"
"\n"
"This program is free software; you can redistribute it and/or\n"
"modify it under the terms of the GNU General Public License\n"
"as published by the Free Software Foundation; either version 2\n"
"of the License, or (at your option) any later version.\n"
"\n"
"This program is distributed in the hope that it will be useful,\n"
"but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n"
"GNU General Public License for more details.\n"
"\n"
"You should have received a copy of the GNU General Public License\n"
"along with this program; if not, write to the Free Software\n"
"Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA\n"
"\n"
"Also add information on how to contact you by electronic and paper mail.\n"
"\n"
"If the program is interactive, make it output a short notice like this when it starts in an interactive mode:\n"
"\n"
"Gnomovision version 69, Copyright (C) year name of author\n"
"Gnomovision comes with ABSOLUTELY NO WARRANTY; for details\n"
"type `show w'.  This is free software, and you are welcome\n"
"to redistribute it under certain conditions; type `show c' \n"
"for details.\n"
"\n"
"The hypothetical commands `show w' and `show c' should show the appropriate parts of the General Public License. Of course, the commands you use may be called something other than `show w' and `show c'; they could even be mouse-clicks or menu items--whatever suits your program.\n"
"\n"
"You should also get your employer (if you work as a programmer) or your school, if any, to sign a \"copyright disclaimer\" for the program, if necessary. Here is a sample; alter the names:\n"
"\n"
"Yoyodyne, Inc., hereby disclaims all copyright\n"
"interest in the program `Gnomovision'\n"
"(which makes passes at compilers) written \n"
"by James Hacker.\n"
"\n"
"signature of Ty Coon, 1 April 1989\n"
"Ty Coon, President of Vice\n"
"\n"
"This General Public License does not permit incorporating your program into proprietary programs. If your program is a subroutine library, you may consider it more useful to permit linking proprietary applications with the library. If this is what you want to do, use the GNU Lesser General Public License instead of this License. "))
        self.tabWidget.changeTab(self.license,self.__tr("License"))
        self.textEdit3.setText(self.__tr("Winresdump\n"
"	This software is used to extract icons from exe-files.\n"
"	Only the sources of the command-line tool are used and included\n"
"	Copyright (c) 1999    Caolan McNamara\n"
"	Licensed under the GPL\n"
"	URL: http://www.skynet.ie/~caolan/pub/winresdump\n"
"\n"
"Silk Icon Set 1.3\n"
"	This is the Iconset used by Swine\n"
"	Copyright (c)   Mark James	\n"
"	This work is licensed under a \n"
"	Creative Commons Attribution 2.5 License\n"
"	URL: http://www.famfamfam.com/lab/icons/silk/"))
        self.tabWidget.changeTab(self.TabPage,self.__tr("Included Wor&ks"))
        self.buttonClose.setText(self.__tr("&Close"))
        self.buttonClose.setAccel(QKeySequence(self.__tr("Alt+C")))


    def __tr(self,s,c = None):
        return qApp.translate("AboutDialog",s,c)
