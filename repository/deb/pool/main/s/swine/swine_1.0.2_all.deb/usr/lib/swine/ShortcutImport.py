# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ShortcutImport.ui'
#
# Created: Thu Sep 20 15:53:49 2012
#      by: PyQt4 UI code generator 4.9.1
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_ShortcutImport(object):
    def setupUi(self, ShortcutImport):
        ShortcutImport.setObjectName(_fromUtf8("ShortcutImport"))
        ShortcutImport.resize(232, 299)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(_fromUtf8(":/icons/images/swine32.png")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        ShortcutImport.setWindowIcon(icon)
        self.verticalLayout = QtGui.QVBoxLayout(ShortcutImport)
        self.verticalLayout.setMargin(1)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.verticalLayout_2 = QtGui.QVBoxLayout()
        self.verticalLayout_2.setSpacing(0)
        self.verticalLayout_2.setMargin(0)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.label = QtGui.QLabel(ShortcutImport)
        self.label.setMargin(3)
        self.label.setObjectName(_fromUtf8("label"))
        self.verticalLayout_2.addWidget(self.label)
        self.shortcutList = QtGui.QListWidget(ShortcutImport)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.shortcutList.sizePolicy().hasHeightForWidth())
        self.shortcutList.setSizePolicy(sizePolicy)
        self.shortcutList.setMouseTracking(False)
        self.shortcutList.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.shortcutList.setAcceptDrops(False)
        self.shortcutList.setEditTriggers(QtGui.QAbstractItemView.SelectedClicked)
        self.shortcutList.setProperty("showDropIndicator", False)
        self.shortcutList.setSelectionMode(QtGui.QAbstractItemView.MultiSelection)
        self.shortcutList.setIconSize(QtCore.QSize(32, 32))
        self.shortcutList.setFlow(QtGui.QListView.LeftToRight)
        self.shortcutList.setProperty("isWrapping", True)
        self.shortcutList.setSpacing(3)
        self.shortcutList.setViewMode(QtGui.QListView.ListMode)
        self.shortcutList.setUniformItemSizes(False)
        self.shortcutList.setWordWrap(True)
        self.shortcutList.setProperty("dragAutoScroll", False)
        self.shortcutList.setProperty("itemsMovable", False)
        self.shortcutList.setObjectName(_fromUtf8("shortcutList"))
        self.verticalLayout_2.addWidget(self.shortcutList)
        self.buttonBox = QtGui.QDialogButtonBox(ShortcutImport)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Save)
        self.buttonBox.setCenterButtons(True)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.verticalLayout_2.addWidget(self.buttonBox)
        self.verticalLayout.addLayout(self.verticalLayout_2)

        self.retranslateUi(ShortcutImport)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("accepted()")), ShortcutImport.importShortcuts)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("rejected()")), ShortcutImport.close)
        QtCore.QMetaObject.connectSlotsByName(ShortcutImport)

    def retranslateUi(self, ShortcutImport):
        ShortcutImport.setWindowTitle(QtGui.QApplication.translate("ShortcutImport", "Import shortcuts", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("ShortcutImport", "Select shortcuts to import:", None, QtGui.QApplication.UnicodeUTF8))

import resources_rc
