# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SlotSettings.ui'
#
# Created: Tue Jul  9 21:30:02 2013
#      by: PyQt4 UI code generator 4.9.1
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_SlotSettings(object):
    def setupUi(self, SlotSettings):
        SlotSettings.setObjectName(_fromUtf8("SlotSettings"))
        SlotSettings.resize(377, 253)
        self.verticalLayout_2 = QtGui.QVBoxLayout(SlotSettings)
        self.verticalLayout_2.setSpacing(5)
        self.verticalLayout_2.setMargin(0)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.tabWidget = QtGui.QTabWidget(SlotSettings)
        self.tabWidget.setObjectName(_fromUtf8("tabWidget"))
        self.generalTab = QtGui.QWidget()
        self.generalTab.setObjectName(_fromUtf8("generalTab"))
        self.formLayout = QtGui.QFormLayout(self.generalTab)
        self.formLayout.setFieldGrowthPolicy(QtGui.QFormLayout.ExpandingFieldsGrow)
        self.formLayout.setObjectName(_fromUtf8("formLayout"))
        self.label = QtGui.QLabel(self.generalTab)
        self.label.setObjectName(_fromUtf8("label"))
        self.formLayout.setWidget(0, QtGui.QFormLayout.LabelRole, self.label)
        self.winePath = QtGui.QComboBox(self.generalTab)
        self.winePath.setSizeAdjustPolicy(QtGui.QComboBox.AdjustToContents)
        self.winePath.setObjectName(_fromUtf8("winePath"))
        self.formLayout.setWidget(0, QtGui.QFormLayout.FieldRole, self.winePath)
        self.tabWidget.addTab(self.generalTab, _fromUtf8(""))
        self.verticalLayout_2.addWidget(self.tabWidget)
        self.buttonBox = QtGui.QDialogButtonBox(SlotSettings)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setCenterButtons(True)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.verticalLayout_2.addWidget(self.buttonBox)

        self.retranslateUi(SlotSettings)
        self.tabWidget.setCurrentIndex(0)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("accepted()")), SlotSettings.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("rejected()")), SlotSettings.reject)
        QtCore.QMetaObject.connectSlotsByName(SlotSettings)

    def retranslateUi(self, SlotSettings):
        SlotSettings.setWindowTitle(QtGui.QApplication.translate("SlotSettings", "Slot settings", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("SlotSettings", "Wine path", None, QtGui.QApplication.UnicodeUTF8))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.generalTab), QtGui.QApplication.translate("SlotSettings", "General", None, QtGui.QApplication.UnicodeUTF8))

import resources_rc
