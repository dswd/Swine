# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'IconDialog.ui'
#
# Created: Sat May 19 09:15:10 2012
#      by: PyQt4 UI code generator 4.9.1
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_IconDialog(object):
    def setupUi(self, IconDialog):
        IconDialog.setObjectName(_fromUtf8("IconDialog"))
        IconDialog.resize(388, 306)
        IconDialog.setWindowTitle(_fromUtf8("TITLE"))
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(_fromUtf8(":/icons/images/swine32.png")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        IconDialog.setWindowIcon(icon)
        self.vboxlayout = QtGui.QVBoxLayout(IconDialog)
        self.vboxlayout.setObjectName(_fromUtf8("vboxlayout"))
        self.iconView = QtGui.QListWidget(IconDialog)
        font = QtGui.QFont()
        font.setPointSize(1)
        font.setKerning(False)
        font.setStyleStrategy(QtGui.QFont.NoAntialias)
        self.iconView.setFont(font)
        self.iconView.setAcceptDrops(False)
        self.iconView.setIconSize(QtCore.QSize(32, 32))
        self.iconView.setFlow(QtGui.QListView.LeftToRight)
        self.iconView.setSpacing(3)
        self.iconView.setViewMode(QtGui.QListView.IconMode)
        self.iconView.setProperty("maxItemTextLength", 0)
        self.iconView.setProperty("itemsMovable", False)
        self.iconView.setProperty("wordWrapIconText", False)
        self.iconView.setObjectName(_fromUtf8("iconView"))
        self.vboxlayout.addWidget(self.iconView)
        self.hboxlayout = QtGui.QHBoxLayout()
        self.hboxlayout.setObjectName(_fromUtf8("hboxlayout"))
        spacerItem = QtGui.QSpacerItem(16, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.hboxlayout.addItem(spacerItem)
        self.okButton = QtGui.QPushButton(IconDialog)
        self.okButton.setObjectName(_fromUtf8("okButton"))
        self.hboxlayout.addWidget(self.okButton)
        spacerItem1 = QtGui.QSpacerItem(16, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.hboxlayout.addItem(spacerItem1)
        self.cancelButton = QtGui.QPushButton(IconDialog)
        self.cancelButton.setObjectName(_fromUtf8("cancelButton"))
        self.hboxlayout.addWidget(self.cancelButton)
        spacerItem2 = QtGui.QSpacerItem(16, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.hboxlayout.addItem(spacerItem2)
        self.vboxlayout.addLayout(self.hboxlayout)

        self.retranslateUi(IconDialog)
        QtCore.QObject.connect(self.cancelButton, QtCore.SIGNAL(_fromUtf8("clicked()")), IconDialog.cancelButton_clicked)
        QtCore.QObject.connect(self.okButton, QtCore.SIGNAL(_fromUtf8("clicked()")), IconDialog.okButton_clicked)
        QtCore.QMetaObject.connectSlotsByName(IconDialog)

    def retranslateUi(self, IconDialog):
        self.okButton.setText(QtGui.QApplication.translate("IconDialog", "OK", None, QtGui.QApplication.UnicodeUTF8))
        self.cancelButton.setText(QtGui.QApplication.translate("IconDialog", "Cancel", None, QtGui.QApplication.UnicodeUTF8))

import resources_rc
