# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'IconDialog.ui'
#
# Created: Thu Oct 18 21:58:52 2012
#      by: PyQt4 UI code generator 4.9.1
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_IconDialog(object):
    def setupUi(self, IconDialog):
        IconDialog.setObjectName(_fromUtf8("IconDialog"))
        IconDialog.resize(388, 306)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(_fromUtf8(":/icons/images/swine32.png")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        IconDialog.setWindowIcon(icon)
        self.vboxlayout = QtGui.QVBoxLayout(IconDialog)
        self.vboxlayout.setSpacing(1)
        self.vboxlayout.setMargin(1)
        self.vboxlayout.setObjectName(_fromUtf8("vboxlayout"))
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.filename = QtGui.QLabel(IconDialog)
        self.filename.setMaximumSize(QtCore.QSize(500, 16777215))
        self.filename.setText(_fromUtf8("FILENAME"))
        self.filename.setObjectName(_fromUtf8("filename"))
        self.horizontalLayout.addWidget(self.filename)
        self.toolButton = QtGui.QToolButton(IconDialog)
        self.toolButton.setText(_fromUtf8("..."))
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap(_fromUtf8(":/icons/images/document-open.png")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.toolButton.setIcon(icon1)
        self.toolButton.setObjectName(_fromUtf8("toolButton"))
        self.horizontalLayout.addWidget(self.toolButton)
        self.vboxlayout.addLayout(self.horizontalLayout)
        self.iconView = QtGui.QListWidget(IconDialog)
        font = QtGui.QFont()
        font.setKerning(False)
        font.setStyleStrategy(QtGui.QFont.NoAntialias)
        self.iconView.setFont(font)
        self.iconView.setAcceptDrops(False)
        self.iconView.setIconSize(QtCore.QSize(32, 32))
        self.iconView.setFlow(QtGui.QListView.LeftToRight)
        self.iconView.setSpacing(3)
        self.iconView.setViewMode(QtGui.QListView.IconMode)
        self.iconView.setProperty("maxItemTextLength", 0)
        self.iconView.setProperty("itemsMovable", False)
        self.iconView.setProperty("wordWrapIconText", False)
        self.iconView.setObjectName(_fromUtf8("iconView"))
        self.vboxlayout.addWidget(self.iconView)
        self.buttonBox = QtGui.QDialogButtonBox(IconDialog)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setCenterButtons(True)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.vboxlayout.addWidget(self.buttonBox)

        self.retranslateUi(IconDialog)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("accepted()")), IconDialog.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("rejected()")), IconDialog.reject)
        QtCore.QObject.connect(self.toolButton, QtCore.SIGNAL(_fromUtf8("pressed()")), IconDialog.openFile)
        QtCore.QMetaObject.connectSlotsByName(IconDialog)

    def retranslateUi(self, IconDialog):
        IconDialog.setWindowTitle(QtGui.QApplication.translate("IconDialog", "Select Icon", None, QtGui.QApplication.UnicodeUTF8))

import resources_rc
