# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'RunnerDialog.ui'
#
# Created: Thu Oct 18 21:58:52 2012
#      by: PyQt4 UI code generator 4.9.1
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_RunnerDialog(object):
    def setupUi(self, RunnerDialog):
        RunnerDialog.setObjectName(_fromUtf8("RunnerDialog"))
        RunnerDialog.resize(204, 312)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(_fromUtf8(":/icons/images/swine32.png")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        RunnerDialog.setWindowIcon(icon)
        self.widget = QtGui.QWidget(RunnerDialog)
        self.widget.setObjectName(_fromUtf8("widget"))
        self.vboxlayout = QtGui.QVBoxLayout(self.widget)
        self.vboxlayout.setSpacing(3)
        self.vboxlayout.setMargin(3)
        self.vboxlayout.setObjectName(_fromUtf8("vboxlayout"))
        self.textLabel1 = QtGui.QLabel(self.widget)
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.textLabel1.setFont(font)
        self.textLabel1.setWordWrap(False)
        self.textLabel1.setObjectName(_fromUtf8("textLabel1"))
        self.vboxlayout.addWidget(self.textLabel1)
        self.slots = QtGui.QListWidget(self.widget)
        self.slots.setIconSize(QtCore.QSize(32, 32))
        self.slots.setObjectName(_fromUtf8("slots"))
        self.vboxlayout.addWidget(self.slots)
        self.selectButton = QtGui.QPushButton(self.widget)
        self.selectButton.setDefault(True)
        self.selectButton.setObjectName(_fromUtf8("selectButton"))
        self.vboxlayout.addWidget(self.selectButton)
        RunnerDialog.setCentralWidget(self.widget)

        self.retranslateUi(RunnerDialog)
        QtCore.QObject.connect(self.selectButton, QtCore.SIGNAL(_fromUtf8("clicked()")), RunnerDialog.selectButton_clicked)
        QtCore.QObject.connect(self.slots, QtCore.SIGNAL(_fromUtf8("returnPressed(QListWidgetItem*)")), RunnerDialog.slots_itemExecuted)
        QtCore.QObject.connect(self.slots, QtCore.SIGNAL(_fromUtf8("doubleClicked(QListWidgetItem*)")), RunnerDialog.slots_itemExecuted)
        QtCore.QMetaObject.connectSlotsByName(RunnerDialog)

    def retranslateUi(self, RunnerDialog):
        RunnerDialog.setWindowTitle(QtGui.QApplication.translate("RunnerDialog", "Swine %s", None, QtGui.QApplication.UnicodeUTF8))
        self.textLabel1.setText(QtGui.QApplication.translate("RunnerDialog", "Please select a slot:", None, QtGui.QApplication.UnicodeUTF8))
        self.selectButton.setText(QtGui.QApplication.translate("RunnerDialog", "Run in this slot", None, QtGui.QApplication.UnicodeUTF8))

import resources_rc
